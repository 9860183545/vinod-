package com.TDDFramework.Utility;

import com.aventstack.extentreports.ExtentTest;

public class ObjectRepo {

	
	public static ExtentTest test;
	
}
